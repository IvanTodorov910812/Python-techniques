create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  pdf_url text,
  extracted_text text,
  created_at timestamptz default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  cv_document uuid references public.documents(id) on delete cascade,
  jd_text text,
  score_json jsonb,
  created_at timestamptz default now()
);

create table if not exists public.analytics (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  event text,
  meta jsonb,
  created_at timestamptz default now()
);

create index if not exists idx_matches_user on public.matches(user_id);
create index if not exists idx_docs_user on public.documents(user_id);
create index if not exists idx_matches_created on public.matches(created_at desc);
