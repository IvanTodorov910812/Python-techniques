import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const PY_API_URL = Deno.env.get("PY_API_URL")!;
const PY_API_KEY = Deno.env.get("PY_API_KEY") || "";

serve(async (req) => {
  try {
    const payload = await req.json();
    const resp = await fetch(`${PY_API_URL}/score`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(PY_API_KEY ? { "x-api-key": PY_API_KEY } : {}),
      },
      body: JSON.stringify(payload),
    });
    return new Response(await resp.text(), {
      status: resp.status,
      headers: { "content-type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { "content-type": "application/json" },
    });
  }
});
