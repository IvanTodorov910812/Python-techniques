# HR AI Candidate Comparison – SaaS (Option A: Supabase + Python + Vercel)

This repo packages the app into three layers:

1) **Python Service (FastAPI)** – runs heavy parsing/ML (spaCy, sentence-transformers, TF‑IDF, fuzzy).
2) **Supabase Edge Functions (Deno)** – secure gateway to Python, optional auth/rate-limit.
3) **Next.js Frontend (Vercel)** – UI + calls Supabase functions.
4) **Supabase Postgres** – persistence for documents, matches, analytics.

## Quickstart

### 1) Build & run the Python service
```bash
cd python-service
docker build -t <your-registry>/cv-python:latest .
docker run -p 8080:8080 <your-registry>/cv-python:latest
# Or push to your registry, then deploy to Fly.io / Azure Container Apps / VM
```

### 2) Deploy Supabase Edge Functions
```bash
# Ensure Supabase CLI is installed and authenticated
cd supabase
supabase functions deploy extract
supabase functions deploy score
# Set env vars in Supabase dashboard for both functions:
#   PY_API_URL = https://<your-python-host>
#   PY_API_KEY = <optional-shared-secret>
```

### 3) Apply DB migrations
```bash
supabase db push
# or:
psql < your connection > -f supabase/migrations/20260211_init.sql
```

### 4) Web (Next.js on Vercel)
- Set `NEXT_PUBLIC_SUPABASE_EDGE_BASE` to your Supabase functions base URL (e.g., `https://<project-ref>.functions.supabase.co`).
- Deploy with Vercel.

## Environments

Create a `.env` for Python (if using API keys), `.env.local` for Next.js, and set Edge Function env in Supabase.

## Security

- Edge Functions are the only public entry point for match/extract; they call Python with `PY_API_KEY` (shared secret).
- Add JWT verification (Supabase Auth) inside the Edge Functions if your app is gated.

## Folders

- `python-service/app/extractor.py` – PDF text/tables extraction, cleaning.
- `python-service/app/scorer.py` – all component scorers, final score.
- `python-service/app/api.py` – `/extract` and `/score` endpoints.
- `supabase/functions/*` – Deno functions that proxy to Python.
- `supabase/migrations` – Postgres schema (documents, matches, analytics).
- `web/lib` – TS API & types for the UI.
