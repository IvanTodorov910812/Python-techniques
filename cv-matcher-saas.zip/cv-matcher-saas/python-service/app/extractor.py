import io
import os
import re
from typing import List
import fitz  # PyMuPDF
import pdfplumber

def extract_text_from_pdf_bytes(pdf_bytes: bytes) -> str:
    text = ""
    with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
        for page in doc:
            text += page.get_text() or ""
    return text

def extract_images_from_pdf_bytes(pdf_bytes: bytes, output_dir: str) -> List[str]:
    os.makedirs(output_dir, exist_ok=True)
    saved = []
    with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
        for page_num, page in enumerate(doc, start=1):
            for img_index, img in enumerate(page.get_images(full=True)):
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]
                image_filename = f"page{page_num}_img{img_index}.{image_ext}"
                with open(os.path.join(output_dir, image_filename), "wb") as f:
                    f.write(image_bytes)
                saved.append(image_filename)
    return saved

def extract_tables_from_pdf_bytes(pdf_bytes: bytes) -> List[List[List[str]]]:
    tables = []
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for page in pdf.pages:
            page_tables = page.extract_tables() or []
            tables.extend(page_tables)
    return tables

def clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\x00-\x7F]+", "", text)
    return text.strip()
