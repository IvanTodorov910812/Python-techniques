import re
import numpy as np
from typing import Dict, Set
from difflib import SequenceMatcher

from fuzzywuzzy import fuzz
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

import spacy
from sentence_transformers import SentenceTransformer, util

_nlp = spacy.load("en_core_web_sm")
_st_model = SentenceTransformer("all-MiniLM-L6-v2")

def extract_skills(text: str) -> Set[str]:
    doc = _nlp(text)
    skills = set()
    for ent in doc.ents:
        if ent.label_ in ["SKILL", "ORG", "PERSON", "NORP", "GPE", "FAC", "PRODUCT", "EVENT", "WORK_OF_ART", "LANGUAGE"]:
            skills.add(ent.text)
    for chunk in doc.noun_chunks:
        if len(chunk.text) > 2:
            skills.add(chunk.text)
    return {s.strip() for s in skills if s.strip()}

def extract_education(text: str) -> str:
    edu_keywords = ["Bachelor", "Master", "PhD", "BSc", "MSc", "Doctorate", "degree", "diploma"]
    for line in text.split("\n"):
        for kw in edu_keywords:
            if kw.lower() in line.lower():
                return line.strip()
    return ""

def extract_title(text: str) -> str:
    m = re.search(r"(?:Job\s*Title|Position|Role)\s*[:\-]\s*([A-Za-z][A-Za-z\s\/\-\(\)&]+)", text, re.IGNORECASE)
    return m.group(1).strip() if m else ""

def skill_match(cv_skills: Set[str], jd_skills: Set[str]) -> float:
    if not cv_skills or not jd_skills:
        return 0.0
    cv = {s.lower() for s in cv_skills}
    jd = {s.lower() for s in jd_skills}
    exact = cv & jd
    exact_score = len(exact) / len(jd) if jd else 0
    remaining_cv = cv - exact
    remaining_jd = jd - exact
    fuzzy_matches = 0
    for cv_skill in remaining_cv:
        for jd_skill in remaining_jd:
            if fuzz.ratio(cv_skill, jd_skill) > 80:
                fuzzy_matches += 1
                break
    fuzzy_score = fuzzy_matches / len(jd) if jd else 0
    return 0.7 * exact_score + 0.3 * fuzzy_score

def extract_years_experience(text: str) -> int:
    m = re.findall(r"(\d+)\+?\s*years?", text, re.IGNORECASE)
    return max(map(int, m)) if m else 0

def experience_match(cv_text: str, jd_text: str) -> int:
    return int(extract_years_experience(cv_text) >= extract_years_experience(jd_text))

def education_match(cv_edu: str, jd_edu: str) -> float:
    if not cv_edu or not jd_edu:
        return 0.0
    edu_levels = {"phd": 4, "doctorate": 4, "master": 3, "msc": 3, "bachelor": 2, "bsc": 2, "diploma": 1}
    cv_l = max((edu_levels.get(k, 0) for k in edu_levels if k in cv_edu.lower()), default=0)
    jd_l = max((edu_levels.get(k, 0) for k in edu_levels if k in jd_edu.lower()), default=0)
    base = fuzz.token_set_ratio(cv_edu, jd_edu) / 100
    if cv_l >= jd_l:
        base = min(1.0, base + 0.2)
    else:
        base *= (1 - (jd_l - cv_l) / 4)
    return float(np.clip(base, 0.0, 1.0))

def title_match(cv_title: str, jd_title: str) -> float:
    if not cv_title or not jd_title:
        return 0.0
    return SequenceMatcher(None, cv_title.lower(), jd_title.lower()).ratio()

def tfidf_similarity(cv_text: str, jd_text: str) -> float:
    tfidf = TfidfVectorizer()
    m = tfidf.fit_transform([cv_text, jd_text])
    return float(cosine_similarity(m[0:1], m[1:2])[0][0])

def semantic_similarity(cv_text: str, jd_text: str) -> float:
    cv_emb = _st_model.encode(cv_text, convert_to_tensor=True)
    jd_emb = _st_model.encode(jd_text, convert_to_tensor=True)
    return float(util.cos_sim(cv_emb, jd_emb).item())

def location_match(cv_text: str, jd_text: str) -> int:
    cv_l = cv_text.lower()
    jd_l = jd_text.lower()
    cv_locations = ["sofia", "haskovo", "bulgaria"]
    jd_locations = ["sofia", "bulgaria"]
    return int(any(loc in cv_l and loc in jd_l for loc in (cv_locations + jd_locations)))

_DOMAIN_PROTOTYPES = {
    "HR": "human resources recruitment employee relations onboarding training payroll",
    "IT": "software development programming data engineer system design cloud devops sap",
    "Finance": "accounting auditing financial analysis budgeting tax banking investment",
    "Logistics": "supply chain transportation warehouse logistics shipping inventory sap ewm",
    "Marketing": "marketing branding campaign seo advertising digital media content",
    "Healthcare": "medical healthcare patient clinical hospital nursing pharmaceutical",
}

from sentence_transformers import util as st_util

def detect_domain(text: str) -> str:
    if not text or len(text.strip()) < 50:
        return "Other"
    labels, texts = zip(*_DOMAIN_PROTOTYPES.items())
    t_emb = _st_model.encode(text.lower(), convert_to_tensor=True)
    d_emb = _st_model.encode(list(texts), convert_to_tensor=True)
    sims = st_util.cos_sim(t_emb, d_emb)[0]
    idx = int(sims.argmax())
    best = float(sims[idx])
    return labels[idx] if best > 0.25 else "Other"

def final_match_score(cv_data: Dict, jd_data: Dict) -> float:
    skill = skill_match(cv_data["skills"], jd_data["skills"])
    sem = semantic_similarity(cv_data["text"], jd_data["text"])
    tfidf = tfidf_similarity(cv_data["text"], jd_data["text"])
    edu = education_match(cv_data["education"], jd_data["education"])
    exp = experience_match(cv_data["text"], jd_data["text"])
    title = title_match(cv_data["title"], jd_data["title"])
    loc = location_match(cv_data["text"], jd_data["text"])

    cv_domain = detect_domain(cv_data.get("text", ""))
    jd_domain = detect_domain(jd_data.get("text", ""))
    domain_penalty = 0.6 if (cv_domain != jd_domain and "Other" not in (cv_domain, jd_domain)) else 1.0

    corr = 1 - abs(title - sem) * 0.1
    sem *= corr
    title *= corr

    if sem > 0.7 and skill < 0.3:
        sem *= 0.7
    if abs(tfidf - sem) > 0.3:
        sem = (sem + tfidf) / 2

    weights = {"skills": 0.15, "semantic": 0.35, "tfidf": 0.20, "education": 0.10, "experience": 0.10, "title": 0.05, "location": 0.05}
    base = (
        weights["skills"] * skill
        + weights["semantic"] * sem
        + weights["tfidf"] * tfidf
        + weights["education"] * edu
        + weights["experience"] * exp
        + weights["title"] * title
        + weights["location"] * loc
    )

    base *= domain_penalty
    consistency = float(np.mean([skill, sem, tfidf]))
    if consistency > 0.7:
        base += 0.05 * consistency
    if skill < 0.4 or sem < 0.4:
        base *= 0.9

    base = min(1.0, base + 0.05)
    final = 1 / (1 + np.exp(-4.5 * (base - 0.45)))
    return float(np.clip(final, 0.0, 1.0))

def build_report(cv_text: str, jd_text: str) -> Dict:
    cv_text_clean = re.sub(r"\s+", " ", cv_text)
    jd_text_clean = re.sub(r"\s+", " ", jd_text)
    cv_data = {
        "text": cv_text_clean,
        "skills": extract_skills(cv_text_clean),
        "title": extract_title(cv_text_clean),
        "education": extract_education(cv_text_clean),
    }
    jd_data = {
        "text": jd_text_clean,
        "skills": extract_skills(jd_text_clean),
        "title": extract_title(jd_text_clean),
        "education": extract_education(jd_text_clean),
    }
    report = {
        "Skill Match": skill_match(cv_data["skills"], jd_data["skills"]),
        "Experience Match": experience_match(cv_data["text"], jd_data["text"]),
        "Education Match": education_match(cv_data["education"], jd_data["education"]),
        "Title Match": title_match(cv_data["title"], jd_data["title"]),
        "TF-IDF Similarity": tfidf_similarity(cv_data["text"], jd_data["text"]),
        "Semantic Similarity": semantic_similarity(cv_data["text"], jd_data["text"]),
        "Location Match": location_match(cv_data["text"], jd_data["text"]),
    }
    report["Final Score"] = final_match_score(cv_data, jd_data)
    return report
