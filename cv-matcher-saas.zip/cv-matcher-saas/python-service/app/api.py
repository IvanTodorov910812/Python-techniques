import base64
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from app.extractor import extract_text_from_pdf_bytes, clean_text
from app.scorer import build_report

app = FastAPI()

API_KEY = None  # set via env/secret manager or leave None to disable

class ExtractReq(BaseModel):
    file_base64: str

class ExtractRes(BaseModel):
    text: str

class ScoreReq(BaseModel):
    cv_text: str
    jd_text: str

@app.post("/extract", response_model=ExtractRes)
def extract(req: ExtractReq, x_api_key: str | None = Header(default=None)):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(401, "Unauthorized")
    pdf_bytes = base64.b64decode(req.file_base64)
    text = extract_text_from_pdf_bytes(pdf_bytes)
    return {"text": clean_text(text)}

@app.post("/score")
def score(req: ScoreReq, x_api_key: str | None = Header(default=None)):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(401, "Unauthorized")
    report = build_report(req.cv_text, req.jd_text)
    return report
