import { ExtractResponse, ScoreResponse } from "./types";

export async function extractPDF(file: File): Promise<ExtractResponse> {
  const base64 = await fileToBase64(file);
  const resp = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_EDGE_BASE}/extract`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ file_base64: base64 }),
    cache: "no-store",
  });
  if (!resp.ok) throw new Error(`extract failed: ${resp.status}`);
  return resp.json();
}

export async function scoreCV(cv_text: string, jd_text: string): Promise<ScoreResponse> {
  const resp = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_EDGE_BASE}/score`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ cv_text, jd_text }),
    cache: "no-store",
  });
  if (!resp.ok) throw new Error(`score failed: ${resp.status}`);
  return resp.json();
}

async function fileToBase64(file: File) {
  const buf = await file.arrayBuffer();
  let binary = "";
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}
