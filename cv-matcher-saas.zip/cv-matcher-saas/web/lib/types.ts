export type ExtractResponse = { text: string };

export type ScoreResponse = {
  "Skill Match": number;
  "Experience Match": number;
  "Education Match": number;
  "Title Match": number;
  "TF-IDF Similarity": number;
  "Semantic Similarity": number;
  "Location Match": number | boolean;
  "Final Score": number;
};
